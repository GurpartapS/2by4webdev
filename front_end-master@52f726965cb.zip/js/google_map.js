
var google;

function init() {
   var mississauga = {
		info: '<strong>MISSISSAUGA</strong>',
		lat: 43.5890,
		long: -79.6441
	};

	var locations = [
      [mississauga.info, mississauga.lat, mississauga.long, 0]
    ];

	var map = new google.maps.Map(document.getElementById('map'), {
		zoom: 8,
		center: new google.maps.LatLng(43.5890, -79.6441),
		mapTypeId: google.maps.MapTypeId.ROADMAP
	});

	var infowindow = new google.maps.InfoWindow({});

	var marker, i;

	for (i = 0; i < locations.length; i++) {
		marker = new google.maps.Marker({
			position: new google.maps.LatLng(locations[i][1], locations[i][2]),
			map: map
		});

		google.maps.event.addListener(marker, 'click', (function (marker, i) {
			return function () {
				infowindow.setContent(locations[i][0]);
				infowindow.open(map, marker);
			}
		})(marker, i));
	}
}
google.maps.event.addDomListener(window, 'load', init);