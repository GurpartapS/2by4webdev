<?php

require __DIR__ . '/vendor/autoload.php';

const DEFAULT_URL = 'https://bestbuydata-299f1.firebaseio.com/';
const DEFAULT_TOKEN = '1rzJ8xXydgkijS035441YQ4MUvAOYZ33gROZmYwz';
const DEFAULT_PATH = '/';

$firebase = new \Firebase\FirebaseLib(DEFAULT_URL, DEFAULT_TOKEN);

$request = array(
    "email" => $_GET["notificationemail"]
);


$requests = $firebase->get(DEFAULT_PATH  . '/2by4gta/notify/');

$json=json_decode($requests,true);
if (!empty($requests)) {
  $highest = max(array_keys($json))+1;
}
else{
	$highest=1;
}

if (!empty($_GET["notificationemail"])) {

$i = 0;
	$numItems = count($json);
	if($numItems>0){
foreach($json as $key => $value) {
 
  if (strpos($value['email'], $_GET['notificationemail']) === 0) {
	break;
  }
  
  if(++$i === $numItems) {

    $firebase->set(DEFAULT_PATH . '/2by4gta/notify/' . $highest . '/', $request);
  }
}

}
else{
	$firebase->set(DEFAULT_PATH . '/2by4gta/notify/' . $highest . '/', $request);
}

}?>
