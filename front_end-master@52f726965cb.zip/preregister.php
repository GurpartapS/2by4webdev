<?php

require __DIR__ . '/vendor/autoload.php';

const DEFAULT_URL = 'https://bestbuydata-299f1.firebaseio.com/';
const DEFAULT_TOKEN = '1rzJ8xXydgkijS035441YQ4MUvAOYZ33gROZmYwz';
const DEFAULT_PATH = '/';

$firebase = new \Firebase\FirebaseLib(DEFAULT_URL, DEFAULT_TOKEN);

$request = array(
    "name" => $_GET["name"],
    "email" => $_GET["email"],
    "phone" => $_GET["phone"],
    "option" => $_GET["option"],
    "others" => $_GET["others"]
);


$requests = $firebase->get(DEFAULT_PATH  . '/2by4gta/preregister/');

$json=json_decode($requests,true);
if (!empty($requests)) {
  $highest = max(array_keys($json))+1;
}
else{
	$highest=1;
}

if (!empty($_GET["email"])) {

$i = 0;
	$numItems = count($json);
	if(!$numItems==0){
foreach($json as $key => $value) {
 
  if (strpos($value['email'], $_GET['email']) === 0) {
	break;
  }
  
  if(++$i === $numItems) {

    $firebase->set(DEFAULT_PATH . '/2by4gta/preregister/' . $highest . '/', $request);
  }
}

}
else{
	$firebase->set(DEFAULT_PATH . '/2by4gta/preregister/' . $highest . '/', $request);
}

}?>
